# -*- coding: utf-8 -*-
import scrapy
from scrapy import Spider
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from soompi.items import SoompiItem

class MusicSpider(CrawlSpider):
	name = 'music'
	allowed_domains = ['soompi.com']
	start_urls = ['https://www.soompi.com/news/']

	rules = [
	Rule(LinkExtractor(
	allow=['/2017/06/20/.*']),
	# callback: whenever you find sth that matches the pattern, call the specified func
	callback='parse_item',
	# follow: find links and call the func repeatedly
	follow=True)
	]


	def parse_item(self, response):

		items = []

		selector_list = response.css('div.content-image')

		for selector in selector_list:
			item = SoompiItem()

			item['title'] = selector.xpath('a/@title').extract()

			item['url'] = selector.xpath('a/@href').extract()
			# item['image_urls'] = selector.xpath('a/img/@src').extract()
			items.append(item)

		return items
