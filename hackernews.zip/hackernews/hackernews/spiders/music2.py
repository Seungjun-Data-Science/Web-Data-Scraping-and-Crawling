# -*- coding: utf-8 -*-
import scrapy
from scrapy import Spider
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from soompi.items import SoompiItem

class MusicSpider(CrawlSpider):
	name = 'music2'
	allowed_domains = ['www.soompi.com']
	start_urls = ['https://www.soompi.com/']

	rules = [\
		Rule(\
			LinkExtractor(\
				canonicalize=True,\
				unique=True\
			),\
			follow=True,\
			callback="parse_item"\
		)\
	]

	def start_requests(self):
		for url in self.start_urls:
			yield scrapy.Request(url, callback=self.parse, dont_filter=True)


	def parse_item(self, response):

		links = LinkExtractor(allow=('/2017/06/18/.*'),\
			canonicalize=True, unique=True).extract_links(response)
		

		for link in links:
			is_allowed = False
			for allowed_domain in self.allowed_domains:
				if allowed_domain in link.url:
					is_allowed = True
			if is_allowed:
				item = SoompiItem()
				
				item['title'] = response.css('div.content-image').\
				xpath('a/@title').extract()
				
				item['url'] = response.css('div.content-image').\
				xpath('a/@href').extract()
		yield item